---
id: output_templates
type: templates
tags: [core]
title: Output Templates
version: 1
updated: 2026-02-14
---

# Output Templates

## 現状サマリ
- 状況：
- 直近の出来事：
- 参照した設定：

## 選択肢（任意）
1) ...
2) ...
3) ...

## 次の入力
- 「次に何をしますか？」または具体的な入力形式を提示
