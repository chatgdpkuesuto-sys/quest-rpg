---
id: index_root
type: index
tags: [must_read]
title: Index
version: 1
updated: 2026-02-14
---

# Index（入口）

> このファイルは `tools/generate_index.py` により自動生成されます。  
> 生成前の暫定版です。

## 必読
- [Principles](../00_Core_Engine/00_Principles.md)
- [World Overview](../01_World_Module/00_World_Overview.md)
- [Character Overview](../02_Character_Data/00_Character_Overview.md)
- [Pattern Overview](../03_Scenario_Patterns/00_Pattern_Overview.md)
