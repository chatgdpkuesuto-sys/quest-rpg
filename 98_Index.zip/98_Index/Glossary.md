---
id: glossary
type: glossary
tags: [index]
title: Glossary
version: 1
updated: 2026-02-14
---

# Glossary

- 用語: 説明（必要なら参照先リンク）
