# Battle
テンプレを置きます。
