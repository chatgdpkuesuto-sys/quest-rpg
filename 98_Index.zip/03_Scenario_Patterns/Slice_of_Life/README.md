# Slice_of_Life
テンプレを置きます。
