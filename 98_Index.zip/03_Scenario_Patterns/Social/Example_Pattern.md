---
id: pattern_social_example
type: pattern
tags: [pattern, social]
title: Social Pattern Example
version: 1
updated: 2026-02-14
---

# Social Pattern Example

## 起点
- ...

## 進行
1. ...
2. ...

## 分岐
- ...
