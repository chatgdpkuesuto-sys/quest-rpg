---
id: loc_example
type: location
tags: [location]
title: Example Location
version: 1
updated: 2026-02-14
---

# Example Location

## 概要
- 役割：
- 雰囲気：

## 重要ポイント
- ...
