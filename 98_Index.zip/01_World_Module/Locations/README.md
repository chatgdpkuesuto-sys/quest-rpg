# Locations
場所の詳細ファイルを置きます。
