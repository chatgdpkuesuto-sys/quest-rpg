---
id: char_example
type: character
tags: [main_cast]
title: Example Character
version: 1
updated: 2026-02-14
---

# Example Character

## 概要
- 役割：
- 口調：
- 関係：

## Data (Sample)
- **Class**: Fighter
- **Level**: 1
- **HP**: 12 / 12
- **AC**: 16 (Chain Mail)

## Ability Scores
| STR | DEX | CON | INT | WIS | CHA |
|:---:|:---:|:---:|:---:|:---:|:---:|
| 16 (+3) | 12 (+1) | 14 (+2) | 10 (+0) | 10 (+0) | 12 (+1) |

## Skills & Attacks
- **Attacks**:
  - Longsword: +5 to hit, 1d8+3 Slashing damage.
- **Skills**: Athletics +5, Intimidation +3

## 行動指針
- 目的：
- 禁止：

## 口調サンプル
- 「」
