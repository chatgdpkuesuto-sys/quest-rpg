# 02_Character_Data

キャラクターの確定情報を置きます。

- `Main_Cast/`：主要キャラ
- `Sub_Cast/`：準主要・サブ
- `NPCs/`：使い捨て/頻出NPC
