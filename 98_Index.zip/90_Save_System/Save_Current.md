---
id: save_current
type: save
tags: [save]
title: Save Current
version: 1
updated: 2026-02-14
---

# Save Current

- 2026-02-14 初期化
